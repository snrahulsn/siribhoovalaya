Siribhūvalaya: digital text and findings
siribhoovalaya.com

grids.csv           every number grid of the poem: one row per grid row (27 numbers), 1,268 pages. Each number is one sound (1 to 64); ? marks a cell that could not be read.
siribhuvalaya.csv   one row per verse or line, all 59 chapters (20,640 rows): chapter, verse, Kannada decoded from the grids, the same in Roman letters split into words, and a first English draft made by machine (not checked by a reader).
hidden_texts.csv    68 passages spelled by one letter from each verse (the Bhagavad Gītā, Jain hymns and scripture, and five verses headed Śrutāvatāra): where they sit, the rule, the grid letters beside the source letters, and the scores.
certification.md    what was confirmed, what was weak, what was not found, and how each was tested.
checks/             the three independent audits, rebuilt from the raw numbers, and the decoy test for the Jain texts.

The English is rough. If you read Old Kannada, please correct it on the website.
Free to use for study and research. Please credit siribhoovalaya.com.
